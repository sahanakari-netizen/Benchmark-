import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["BENCH_DB_PATH"] = "/tmp/test_benchmark.db"
if os.path.exists("/tmp/test_benchmark.db"):
    os.remove("/tmp/test_benchmark.db")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)
client.__enter__()  # trigger startup event (init_db + seed)


def test_health():
    assert client.get("/health").json() == {"status": "ok"}


def test_builtin_agents_and_tasks_seeded():
    agents = {a["name"] for a in client.get("/agents").json()}
    assert {"robust_agent", "naive_agent"} <= agents
    tasks = client.get("/tasks").json()
    assert len(tasks) >= 5


def _ids():
    agents = {a["name"]: a["id"] for a in client.get("/agents").json()}
    tasks = {t["name"]: t["id"] for t in client.get("/tasks").json()}
    return agents, tasks


def test_robust_agent_succeeds_clean_run():
    agents, tasks = _ids()
    task_id = tasks["Capital of France"]
    runs = client.post("/runs", json={
        "agent_id": agents["robust_agent"], "task_id": task_id, "repeats": 1,
        "fault": {"tool_failure": False, "model_unavailable": False, "misleading_instructions": False},
    }).json()
    assert runs[0]["success"] is True
    assert "paris" in runs[0]["final_answer"].lower()


def test_robust_agent_survives_tool_failure_naive_does_not():
    agents, tasks = _ids()
    task_id = tasks["Capital of Japan"]

    robust_runs = client.post("/runs", json={
        "agent_id": agents["robust_agent"], "task_id": task_id, "repeats": 1,
        "fault": {"tool_failure": True, "model_unavailable": False, "misleading_instructions": False},
    }).json()
    assert robust_runs[0]["success"] is True  # retried and recovered

    naive_runs = client.post("/runs", json={
        "agent_id": agents["naive_agent"], "task_id": task_id, "repeats": 1,
        "fault": {"tool_failure": True, "model_unavailable": False, "misleading_instructions": False},
    }).json()
    assert naive_runs[0]["success"] is False  # no retry logic -> fails


def test_misleading_instructions_fool_naive_not_robust():
    agents, tasks = _ids()
    task_id = tasks["Capital of Italy (robustness probe)"]

    robust_runs = client.post("/runs", json={
        "agent_id": agents["robust_agent"], "task_id": task_id, "repeats": 1,
        "fault": {"tool_failure": False, "model_unavailable": False, "misleading_instructions": True},
    }).json()
    assert robust_runs[0]["success"] is True

    naive_runs = client.post("/runs", json={
        "agent_id": agents["naive_agent"], "task_id": task_id, "repeats": 1,
        "fault": {"tool_failure": False, "model_unavailable": False, "misleading_instructions": True},
    }).json()
    assert naive_runs[0]["success"] is False


def test_compare_endpoint():
    agents, tasks = _ids()
    task_id = tasks["Arithmetic sum"]
    for name in ("robust_agent", "naive_agent"):
        client.post("/runs", json={"agent_id": agents[name], "task_id": task_id, "repeats": 2, "fault": {}})
    ids = f"{agents['robust_agent']},{agents['naive_agent']}"
    rows = client.get(f"/compare?agent_ids={ids}&task_id={task_id}").json()
    assert len(rows) == 2
    assert all(r["runs"] == 2 for r in rows)


def test_register_external_agent():
    created = client.post("/agents", json={
        "name": "demo_external", "endpoint_url": "http://127.0.0.1:9999/invoke", "description": "test",
    }).json()
    assert created["kind"] == "http"
    assert created["endpoint_url"] == "http://127.0.0.1:9999/invoke"
