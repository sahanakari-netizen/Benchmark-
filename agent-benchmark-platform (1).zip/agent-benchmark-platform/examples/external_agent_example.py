"""A minimal standalone example of a THIRD-PARTY agent implementing the
platform's HTTP contract. Run it as its own process on its own port,
then register it with the platform:

    uvicorn examples.external_agent_example:app --port 9001
    curl -X POST http://127.0.0.1:8002/agents -H "Content-Type: application/json" \\
        -d '{"name":"example_external","endpoint_url":"http://127.0.0.1:9001/invoke","description":"demo external agent"}'

This file has NO import dependency on the platform itself -- that's
the point. Any agent, in any framework, just needs to accept this JSON
shape and return this JSON shape to be benchmarked.
"""
import re

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Example External Agent")

_KB = {"france": "Paris", "japan": "Tokyo", "italy": "Rome", "germany": "Berlin"}


class AgentRequestIn(BaseModel):
    task_id: str
    prompt: str
    available_tools: list[str] = []
    inject_tool_failure: bool = False
    inject_model_unavailable: bool = False
    inject_misleading_instructions: bool = False


@app.post("/invoke")
def invoke(req: AgentRequestIn):
    steps = [{"type": "reasoning", "detail": "Looking for a country name in the prompt."}]
    answer = "unknown"

    if req.inject_model_unavailable:
        steps.append({"type": "tool_error", "detail": "model backend unreachable"})
        return {"final_answer": "error: model unavailable", "steps": steps, "tool_calls": 0,
                "tokens_used": 8, "cost_usd": 0.0}

    m = re.search(r"capital of (\w+)", req.prompt, re.I)
    if m:
        country = m.group(1).lower()
        if req.inject_tool_failure:
            steps.append({"type": "tool_error", "detail": "search tool failed, retrying"})
        answer = _KB.get(country, "unknown")
        steps.append({"type": "tool_call", "detail": f"search('capital of {country}') -> {answer}"})

    return {"final_answer": answer, "steps": steps, "tool_calls": 1,
            "tokens_used": 35, "cost_usd": 0.00014}
