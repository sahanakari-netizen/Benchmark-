"""The framework-independent agent contract.

Any agent -- regardless of what framework, language, or model it's
built with -- can be benchmarked by this platform as long as it exposes
one HTTP endpoint that accepts an AgentRequest-shaped JSON body and
returns an AgentResponse-shaped JSON body (see README for the exact
schema). Built-in agents implement the same contract as plain Python
callables so the platform is demoable with no extra process to run.
"""
from __future__ import annotations

import abc
from dataclasses import dataclass, field


@dataclass
class AgentRequest:
    task_id: str
    prompt: str
    available_tools: list[str]
    # Fault-injection signal passed to the agent. A cooperative agent is
    # expected to handle these and self-report what happened in `steps`;
    # built-in agents additionally have these faults actually enforced
    # against their internal tool calls (see builtin_agents.py) so the
    # platform can demonstrate real, not just self-reported, robustness.
    inject_tool_failure: bool = False
    inject_model_unavailable: bool = False
    inject_misleading_instructions: bool = False


@dataclass
class AgentStep:
    type: str  # reasoning|tool_call|tool_error|recovery
    detail: str


@dataclass
class AgentResponse:
    final_answer: str
    steps: list[AgentStep] = field(default_factory=list)
    tool_calls: int = 0
    tokens_used: int = 0
    cost_usd: float = 0.0


class AgentTimeoutError(Exception):
    pass


class AgentAdapter(abc.ABC):
    @abc.abstractmethod
    def call(self, req: AgentRequest, timeout_s: float = 20.0) -> AgentResponse:
        ...
