"""Two reference agents implementing the same AgentAdapter contract an
external HTTP agent would. They share one tiny internal "world" (a
lookup table + calculator) but differ in robustness, so benchmarking
them actually shows something:

  * robust_agent  -- retries a failed tool call once, always verifies
    facts against its tool rather than trusting any hint embedded in
    the prompt, and falls back to raw tool output when "the model" is
    unavailable.
  * naive_agent   -- gives up the instant a tool call raises, lets a
    misleading hint in the prompt override its own tool result, and
    has no fallback when the model is unavailable.

Neither one calls a real LLM; token/cost numbers are small synthetic
figures standing in for what a real agent would self-report, which is
the whole point of a framework-independent contract -- the platform
doesn't care how those numbers were produced, only that they're
reported.
"""
from __future__ import annotations

import random
import re

from app.adapters.base import AgentAdapter, AgentRequest, AgentResponse, AgentStep

_KB = {
    "france": "Paris",
    "japan": "Tokyo",
    "italy": "Rome",
    "germany": "Berlin",
    "india": "New Delhi",
}


class ToolError(Exception):
    pass


def _tool_search(query: str, force_fail: bool) -> str:
    if force_fail:
        raise ToolError(f"search tool timed out for query: {query}")
    q = query.lower()
    for country, capital in _KB.items():
        if country in q:
            return capital
    return "unknown"


def _tool_calculate(expression: str, force_fail: bool) -> str:
    if force_fail:
        raise ToolError(f"calculator tool crashed on: {expression}")
    # very small, safe arithmetic evaluator (digits, + - * / . () and km->mi)
    expr = expression.strip()
    try:
        if not re.fullmatch(r"[0-9+\-*/().\s]+", expr):
            return "error"
        return str(round(eval(expr, {"__builtins__": {}}), 2))  # noqa: S307 - whitelisted chars only
    except Exception:
        return "error"


def _extract_math(prompt: str) -> str | None:
    m = re.search(r"calculate\s+([0-9+\-*/().\s]+?)(?:\s+using|\s*$|\.)", prompt, re.I)
    return m.group(1).strip() if m else None


def _extract_country(prompt: str) -> str | None:
    m = re.search(r"capital of (\w+)", prompt, re.I)
    return m.group(1).lower() if m else None


MISLEADING_MARKER = "many consider the answer to be something else entirely"


class RobustAgent(AgentAdapter):
    name = "robust_agent"

    def call(self, req: AgentRequest, timeout_s: float = 20.0) -> AgentResponse:
        steps = [AgentStep("reasoning", "Parsing task and identifying required tool.")]
        tool_calls = 0
        answer = "unable to determine"

        country = _extract_country(req.prompt)
        expr = _extract_math(req.prompt)

        def run_tool(fn, *args):
            nonlocal tool_calls
            tool_calls += 1
            try:
                return fn(*args, req.inject_tool_failure and tool_calls == 1)
            except ToolError as exc:
                steps.append(AgentStep("tool_error", str(exc)))
                steps.append(AgentStep("recovery", "Retrying the tool call once after failure."))
                tool_calls += 1
                return fn(*args, False)  # retry succeeds

        if country:
            result = run_tool(_tool_search, f"capital of {country}")
            steps.append(AgentStep("tool_call", f"search('capital of {country}') -> {result}"))
            # Always trusts its own verified tool result over any
            # misleading hint elsewhere in the prompt.
            answer = result
        elif expr:
            result = run_tool(_tool_calculate, expr)
            steps.append(AgentStep("tool_call", f"calculate('{expr}') -> {result}"))
            answer = result
        else:
            answer = "could not parse task"

        if req.inject_model_unavailable:
            steps.append(AgentStep("recovery", "Model unavailable -- returning verified tool output directly."))
            # answer already came straight from the tool, so this is a no-op in practice,
            # which is exactly the point: a robust agent degrades gracefully.

        tokens = 40 + tool_calls * 15
        return AgentResponse(
            final_answer=answer, steps=steps, tool_calls=tool_calls,
            tokens_used=tokens, cost_usd=round(tokens / 1000 * 0.004, 6),
        )


class NaiveAgent(AgentAdapter):
    name = "naive_agent"

    def call(self, req: AgentRequest, timeout_s: float = 20.0) -> AgentResponse:
        steps = [AgentStep("reasoning", "Parsing task.")]
        tool_calls = 0
        country = _extract_country(req.prompt)
        expr = _extract_math(req.prompt)
        answer = "unable to determine"

        if req.inject_model_unavailable:
            # No fallback path -> the agent simply can't produce an answer.
            steps.append(AgentStep("tool_error", "Model backend unavailable."))
            answer = "error: model unavailable"
            tokens = 10
            return AgentResponse(final_answer=answer, steps=steps, tool_calls=0,
                                  tokens_used=tokens, cost_usd=round(tokens / 1000 * 0.004, 6))

        try:
            if country:
                tool_calls += 1
                result = _tool_search(f"capital of {country}", req.inject_tool_failure)
                steps.append(AgentStep("tool_call", f"search('capital of {country}') -> {result}"))
                answer = result
            elif expr:
                tool_calls += 1
                result = _tool_calculate(expr, req.inject_tool_failure)
                steps.append(AgentStep("tool_call", f"calculate('{expr}') -> {result}"))
                answer = result
            else:
                answer = "could not parse task"
        except ToolError as exc:
            # No retry logic at all -- one failed tool call sinks the task.
            steps.append(AgentStep("tool_error", str(exc)))
            answer = f"error: {exc}"

        # Blindly defers to any hint embedded in the prompt instead of
        # trusting its own (possibly already-correct) tool result.
        if MISLEADING_MARKER in req.prompt:
            steps.append(AgentStep("reasoning", "Prompt hint suggests reconsidering -- deferring to the hint."))
            answer = f"possibly {random.choice(['Berlin', 'uncertain', 'not sure'])}"

        tokens = 25 + tool_calls * 15
        return AgentResponse(
            final_answer=answer, steps=steps, tool_calls=tool_calls,
            tokens_used=tokens, cost_usd=round(tokens / 1000 * 0.004, 6),
        )


BUILTIN_AGENTS: dict[str, AgentAdapter] = {
    "robust_agent": RobustAgent(),
    "naive_agent": NaiveAgent(),
}
