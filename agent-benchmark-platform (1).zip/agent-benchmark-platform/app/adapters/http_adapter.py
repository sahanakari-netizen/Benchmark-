"""Calls an arbitrary external agent over HTTP per the published
contract. This is what makes the platform framework-independent: the
agent under test can be written in any stack at all, as long as it
answers this one POST with this one JSON shape.
"""
import dataclasses

import httpx

from app.adapters.base import AgentAdapter, AgentRequest, AgentResponse, AgentStep, AgentTimeoutError


class HTTPAgentAdapter(AgentAdapter):
    def __init__(self, endpoint_url: str):
        self.endpoint_url = endpoint_url

    def call(self, req: AgentRequest, timeout_s: float = 20.0) -> AgentResponse:
        body = dataclasses.asdict(req)
        try:
            resp = httpx.post(self.endpoint_url, json=body, timeout=timeout_s)
            resp.raise_for_status()
            data = resp.json()
        except httpx.TimeoutException as exc:
            raise AgentTimeoutError(str(exc)) from exc
        steps = [AgentStep(**s) for s in data.get("steps", [])]
        return AgentResponse(
            final_answer=data.get("final_answer", ""),
            steps=steps,
            tool_calls=int(data.get("tool_calls", 0)),
            tokens_used=int(data.get("tokens_used", 0)),
            cost_usd=float(data.get("cost_usd", 0.0)),
        )
