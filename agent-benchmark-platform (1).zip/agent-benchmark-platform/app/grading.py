def grade(final_answer: str, expected_keywords: list[str]) -> bool:
    """Success = every expected keyword appears (case-insensitive) in
    the agent's final answer. Simple, transparent, and framework-
    independent -- it only looks at the text the agent reported."""
    if not expected_keywords:
        return bool(final_answer.strip())
    lower = final_answer.lower()
    return all(kw.lower() in lower for kw in expected_keywords)
