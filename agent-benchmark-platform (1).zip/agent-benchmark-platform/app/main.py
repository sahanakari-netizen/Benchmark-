import os
from collections import defaultdict

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from app import runner, schemas, seed
from app.database import get_db, init_db
from app.models import Agent, BenchTask, Run

app = FastAPI(title="AI Agent Benchmarking Platform", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.on_event("startup")
def _startup():
    init_db()
    db = next(get_db())
    try:
        seed.seed(db)
    finally:
        db.close()


@app.get("/health")
def health():
    return {"status": "ok"}


# --------------------------------------------------------------- agents
@app.post("/agents", response_model=schemas.AgentOut)
def register_agent(payload: schemas.AgentCreate, db: Session = Depends(get_db)):
    if db.query(Agent).filter(Agent.name == payload.name).first():
        raise HTTPException(400, "agent name already registered")
    agent = Agent(name=payload.name, kind="http", endpoint_url=payload.endpoint_url,
                  description=payload.description)
    db.add(agent)
    db.commit()
    db.refresh(agent)
    return agent


@app.get("/agents", response_model=list[schemas.AgentOut])
def list_agents(db: Session = Depends(get_db)):
    return db.query(Agent).all()


# ---------------------------------------------------------------- tasks
@app.post("/tasks", response_model=schemas.BenchTaskOut)
def create_task(payload: schemas.BenchTaskCreate, db: Session = Depends(get_db)):
    import json
    task = BenchTask(
        name=payload.name, prompt=payload.prompt, task_type=payload.task_type,
        available_tools=json.dumps(payload.available_tools),
        expected_keywords=json.dumps(payload.expected_keywords),
        difficulty=payload.difficulty,
    )
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


@app.get("/tasks", response_model=list[schemas.BenchTaskOut])
def list_tasks(db: Session = Depends(get_db)):
    return db.query(BenchTask).all()


# ----------------------------------------------------------------- runs
@app.post("/runs", response_model=list[schemas.RunOut])
def trigger_run(payload: schemas.RunRequest, db: Session = Depends(get_db)):
    agent = db.get(Agent, payload.agent_id)
    task = db.get(BenchTask, payload.task_id)
    if not agent or not task:
        raise HTTPException(404, "agent or task not found")
    runs = runner.run_batch(db, agent, task, payload.repeats, payload.fault)
    return runs


@app.get("/runs", response_model=list[schemas.RunOut])
def list_runs(agent_id: str | None = None, task_id: str | None = None,
               db: Session = Depends(get_db)):
    q = db.query(Run)
    if agent_id:
        q = q.filter(Run.agent_id == agent_id)
    if task_id:
        q = q.filter(Run.task_id == task_id)
    return q.order_by(Run.created_at.desc()).limit(500).all()


@app.get("/runs/{run_id}", response_model=schemas.RunOut)
def get_run(run_id: str, db: Session = Depends(get_db)):
    run = db.get(Run, run_id)
    if not run:
        raise HTTPException(404, "not found")
    return run


# ------------------------------------------------------------- compare
@app.get("/compare", response_model=list[schemas.CompareRow])
def compare(agent_ids: str = Query(..., description="comma-separated agent ids"),
            task_id: str | None = None, db: Session = Depends(get_db)):
    ids = [a for a in agent_ids.split(",") if a]
    q = db.query(Run).filter(Run.agent_id.in_(ids))
    if task_id:
        q = q.filter(Run.task_id == task_id)
    runs = q.all()

    grouped: dict[str, list[Run]] = defaultdict(list)
    for r in runs:
        grouped[r.agent_id].append(r)

    rows: list[schemas.CompareRow] = []
    for agent_id, agent_runs in grouped.items():
        agent = db.get(Agent, agent_id)
        n = len(agent_runs)
        rows.append(schemas.CompareRow(
            agent_id=agent_id, agent_name=agent.name if agent else agent_id,
            task_id=task_id, task_name=db.get(BenchTask, task_id).name if task_id else None,
            runs=n,
            success_rate=round(sum(1 for r in agent_runs if r.success) / n, 3) if n else 0.0,
            avg_steps=round(sum(r.steps_count for r in agent_runs) / n, 2) if n else 0.0,
            avg_tool_calls=round(sum(r.tool_calls_count for r in agent_runs) / n, 2) if n else 0.0,
            avg_tokens=round(sum(r.tokens_used for r in agent_runs) / n, 2) if n else 0.0,
            avg_cost_usd=round(sum(r.cost_usd for r in agent_runs) / n, 6) if n else 0.0,
            avg_duration_ms=round(sum(r.duration_ms for r in agent_runs) / n, 2) if n else 0.0,
        ))
    rows.sort(key=lambda r: (-r.success_rate, r.avg_cost_usd))
    return rows


# ------------------------------------------------------------- frontend
_frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(_frontend_dir):
    app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")
