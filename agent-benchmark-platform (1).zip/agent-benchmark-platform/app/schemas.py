from typing import Optional, List
from pydantic import BaseModel, ConfigDict, Field


class AgentCreate(BaseModel):
    name: str
    endpoint_url: str
    description: str = ""


class AgentOut(BaseModel):
    id: str
    name: str
    kind: str
    endpoint_url: Optional[str]
    description: str

    class Config:
        from_attributes = True


class BenchTaskCreate(BaseModel):
    name: str
    prompt: str
    task_type: str = "qa"
    available_tools: List[str] = []
    expected_keywords: List[str] = []
    difficulty: str = "easy"


class BenchTaskOut(BaseModel):
    id: str
    name: str
    prompt: str
    task_type: str
    difficulty: str

    class Config:
        from_attributes = True


class FaultConfig(BaseModel):
    model_config = ConfigDict(protected_namespaces=())

    tool_failure: bool = False
    model_unavailable: bool = False
    misleading_instructions: bool = False


class RunRequest(BaseModel):
    agent_id: str
    task_id: str
    repeats: int = Field(default=1, ge=1, le=20)
    fault: FaultConfig = FaultConfig()


class RunOut(BaseModel):
    id: str
    batch_id: str
    agent_id: str
    task_id: str
    inject_tool_failure: bool
    inject_model_unavailable: bool
    inject_misleading: bool
    status: str
    success: Optional[bool]
    final_answer: str
    steps_count: int
    tool_calls_count: int
    tokens_used: int
    cost_usd: float
    duration_ms: float
    trace_json: str
    error: str

    class Config:
        from_attributes = True


class CompareRow(BaseModel):
    agent_id: str
    agent_name: str
    task_id: Optional[str] = None
    task_name: Optional[str] = None
    runs: int
    success_rate: float
    avg_steps: float
    avg_tool_calls: float
    avg_tokens: float
    avg_cost_usd: float
    avg_duration_ms: float
