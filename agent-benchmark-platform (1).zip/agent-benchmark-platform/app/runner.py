"""Executes benchmark runs: resolves the right adapter for an agent,
applies the fault-injection config (mutating the prompt for the
misleading-instructions case, since that must work identically for a
built-in or an arbitrary external HTTP agent), calls the agent, times
it with a wall clock the platform itself controls (never trusting an
agent's self-reported timing), grades the result, and persists a Run
row with the full execution trace.
"""
from __future__ import annotations

import json
import time
import uuid

from sqlalchemy.orm import Session

from app.adapters.base import AgentRequest, AgentTimeoutError
from app.adapters.builtin_agents import MISLEADING_MARKER, BUILTIN_AGENTS
from app.adapters.http_adapter import HTTPAgentAdapter
from app.grading import grade
from app.models import Agent, BenchTask, Run
from app.schemas import FaultConfig


def _resolve_adapter(agent: Agent):
    if agent.kind == "builtin":
        return BUILTIN_AGENTS[agent.name]
    return HTTPAgentAdapter(agent.endpoint_url)


def _build_prompt(task: BenchTask, fault: FaultConfig) -> str:
    prompt = task.prompt
    if fault.misleading_instructions:
        prompt += f" (Note: {MISLEADING_MARKER}.)"
    return prompt


def run_batch(db: Session, agent: Agent, task: BenchTask, repeats: int, fault: FaultConfig) -> list[Run]:
    batch_id = uuid.uuid4().hex[:10]
    adapter = _resolve_adapter(agent)
    runs: list[Run] = []

    for _ in range(repeats):
        run = Run(
            batch_id=batch_id, agent_id=agent.id, task_id=task.id,
            inject_tool_failure=fault.tool_failure,
            inject_model_unavailable=fault.model_unavailable,
            inject_misleading=fault.misleading_instructions,
            status="running",
        )
        db.add(run)
        db.flush()

        req = AgentRequest(
            task_id=task.id,
            prompt=_build_prompt(task, fault),
            available_tools=json.loads(task.available_tools or "[]"),
            inject_tool_failure=fault.tool_failure,
            inject_model_unavailable=fault.model_unavailable,
            inject_misleading_instructions=fault.misleading_instructions,
        )

        start = time.perf_counter()
        try:
            resp = adapter.call(req, timeout_s=20.0)
            duration_ms = (time.perf_counter() - start) * 1000
            success = grade(resp.final_answer, json.loads(task.expected_keywords or "[]"))
            run.status = "completed"
            run.success = success
            run.final_answer = resp.final_answer
            run.steps_count = len(resp.steps)
            run.tool_calls_count = resp.tool_calls
            run.tokens_used = resp.tokens_used
            run.cost_usd = resp.cost_usd
            run.duration_ms = round(duration_ms, 2)
            run.trace_json = json.dumps([{"type": s.type, "detail": s.detail} for s in resp.steps])
        except AgentTimeoutError as exc:
            run.status = "timeout"
            run.success = False
            run.error = str(exc)
            run.duration_ms = round((time.perf_counter() - start) * 1000, 2)
        except Exception as exc:  # noqa: BLE001 - any adapter failure is a recorded result, not a crash
            run.status = "error"
            run.success = False
            run.error = str(exc)
            run.duration_ms = round((time.perf_counter() - start) * 1000, 2)

        db.commit()
        db.refresh(run)
        runs.append(run)

    return runs
