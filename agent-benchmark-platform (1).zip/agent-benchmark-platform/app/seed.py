"""Seeds the two built-in reference agents and a small demo task suite
so the platform is immediately usable with zero setup."""
import json

from sqlalchemy.orm import Session

from app.models import Agent, BenchTask

DEMO_TASKS = [
    dict(name="Capital of France", task_type="tool_use",
         prompt="Use the search tool to find the capital of France and answer with just the city name.",
         available_tools=["search"], expected_keywords=["paris"], difficulty="easy"),
    dict(name="Capital of Japan", task_type="tool_use",
         prompt="Use the search tool to find the capital of Japan and answer with just the city name.",
         available_tools=["search"], expected_keywords=["tokyo"], difficulty="easy"),
    dict(name="Arithmetic sum", task_type="math",
         prompt="Calculate 47 + 58 using the calculator tool and state only the numeric result.",
         available_tools=["calculate"], expected_keywords=["105"], difficulty="easy"),
    dict(name="Arithmetic product", task_type="math",
         prompt="Calculate 12 * 9 using the calculator tool and state only the numeric result.",
         available_tools=["calculate"], expected_keywords=["108"], difficulty="easy"),
    dict(name="Capital of Italy (robustness probe)", task_type="tool_use",
         prompt="Use the search tool to find the capital of Italy and answer with just the city name.",
         available_tools=["search"], expected_keywords=["rome"], difficulty="medium"),
]


def seed(db: Session) -> None:
    if not db.query(Agent).filter(Agent.name == "robust_agent").first():
        db.add(Agent(name="robust_agent", kind="builtin",
                      description="Reference agent: retries failed tools once, trusts verified tool output over prompt hints, degrades gracefully when the model is unavailable."))
    if not db.query(Agent).filter(Agent.name == "naive_agent").first():
        db.add(Agent(name="naive_agent", kind="builtin",
                      description="Reference agent: no retry on tool failure, defers to misleading prompt hints, no fallback when the model is unavailable."))
    for t in DEMO_TASKS:
        if not db.query(BenchTask).filter(BenchTask.name == t["name"]).first():
            db.add(BenchTask(
                name=t["name"], prompt=t["prompt"], task_type=t["task_type"],
                available_tools=json.dumps(t["available_tools"]),
                expected_keywords=json.dumps(t["expected_keywords"]),
                difficulty=t["difficulty"],
            ))
    db.commit()
