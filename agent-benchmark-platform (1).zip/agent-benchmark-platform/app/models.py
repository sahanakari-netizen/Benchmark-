import datetime
import uuid

from sqlalchemy import Column, String, Float, Integer, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship

from app.database import Base


def gen_id() -> str:
    return uuid.uuid4().hex[:12]


class Agent(Base):
    """A registered agent under test. `kind='builtin'` ones run
    in-process (so the platform is demoable with zero extra servers);
    `kind='http'` ones are called over HTTP at `endpoint_url`, which is
    what makes the platform framework-independent -- any agent, in any
    framework or language, can be benchmarked as long as it exposes the
    documented HTTP contract (see README)."""
    __tablename__ = "agents"

    id = Column(String, primary_key=True, default=gen_id)
    name = Column(String, nullable=False, unique=True)
    kind = Column(String, nullable=False, default="http")  # http|builtin
    endpoint_url = Column(String, nullable=True)
    description = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class BenchTask(Base):
    """One task in the shared benchmark suite, run identically against
    every agent under test."""
    __tablename__ = "bench_tasks"

    id = Column(String, primary_key=True, default=gen_id)
    name = Column(String, nullable=False)
    prompt = Column(Text, nullable=False)
    task_type = Column(String, default="qa")  # qa|tool_use|math
    available_tools = Column(Text, default="[]")  # JSON list
    expected_keywords = Column(Text, default="[]")  # JSON list - ALL must appear (case-insensitive) in final answer
    difficulty = Column(String, default="easy")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)


class Run(Base):
    """One execution of one agent against one task, under one fault
    configuration. A benchmark "run batch" is just several Run rows
    sharing a `batch_id`."""
    __tablename__ = "runs"

    id = Column(String, primary_key=True, default=gen_id)
    batch_id = Column(String, nullable=False, index=True)
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    task_id = Column(String, ForeignKey("bench_tasks.id"), nullable=False)

    # fault injection config for this run
    inject_tool_failure = Column(Boolean, default=False)
    inject_model_unavailable = Column(Boolean, default=False)
    inject_misleading = Column(Boolean, default=False)

    status = Column(String, default="running")  # running|completed|error|timeout
    success = Column(Boolean, nullable=True)
    final_answer = Column(Text, default="")
    steps_count = Column(Integer, default=0)
    tool_calls_count = Column(Integer, default=0)
    tokens_used = Column(Integer, default=0)
    cost_usd = Column(Float, default=0.0)
    duration_ms = Column(Float, default=0.0)
    trace_json = Column(Text, default="[]")
    error = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

    agent = relationship("Agent")
    task = relationship("BenchTask")
